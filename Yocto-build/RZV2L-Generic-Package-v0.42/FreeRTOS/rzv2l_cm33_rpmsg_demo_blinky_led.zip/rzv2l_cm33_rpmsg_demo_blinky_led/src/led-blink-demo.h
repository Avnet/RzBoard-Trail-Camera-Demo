/*
 * led-blink-demo.h
 *
 *  Created on: Jan 5, 2023
 *      Author: son.nguyen-cong
 */

#ifndef LED_BLINK_DEMO_H_
#define LED_BLINK_DEMO_H_

//#define BOARD_RZV2L
#define BOARD_AVNET

void blink_led_demo();

#endif /* LED_BLINK_DEMO_H_ */
