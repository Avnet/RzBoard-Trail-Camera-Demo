/*
 * led-blink-demo.c
 *
 *  Created on: Jan 5, 2023
 *      Author: son.nguyen-cong
 */

#include "bsp_api.h"
#include "platform_info.h"
#include "led-blink-demo.h"

#if defined(BOARD_RZV2L)
static const uint16_t g_bsp_prv_leds_2[] =
{
    (uint16_t) BSP_IO_PORT_43_PIN_00,  ///< LED1 : J1.7
    (uint16_t) BSP_IO_PORT_43_PIN_02,  ///< LED2 : J1.8
    (uint16_t) BSP_IO_PORT_41_PIN_00,  ///< LED3 : J1.9
    (uint16_t) BSP_IO_PORT_43_PIN_01,  ///< LED4 : J1.10
};
#endif

#if defined(BOARD_AVNET)
static const uint16_t g_bsp_prv_leds_2[] =
{
    (uint16_t) BSP_IO_PORT_19_PIN_01,  ///< LED-Blue
    (uint16_t) BSP_IO_PORT_17_PIN_02,  ///< LED-Green
    (uint16_t) BSP_IO_PORT_08_PIN_01,  ///< LED-Red
};
#endif

const bsp_leds_t g_bsp_leds_2 =
{
    .led_count = (uint16_t) ((sizeof(g_bsp_prv_leds_2)) / (sizeof(g_bsp_prv_leds_2[0]))),
    .p_leds    = &g_bsp_prv_leds_2[0]
};


void blink_led_demo(){
    LPRINTF("-----> blink_led_demo\n");
    for(int i=0;i<3;i++){
        R_BSP_PinWrite((bsp_io_port_pin_t) g_bsp_leds_2.p_leds[i], BSP_IO_LEVEL_LOW);
    }

    while(1) {
        R_BSP_PinWrite((bsp_io_port_pin_t) g_bsp_leds_2.p_leds[2], BSP_IO_LEVEL_HIGH);
        LPRINTF("-----> led_on\n");
        vTaskDelay(300 / portTICK_PERIOD_MS);
        R_BSP_PinWrite((bsp_io_port_pin_t) g_bsp_leds_2.p_leds[2], BSP_IO_LEVEL_LOW);
        LPRINTF("-----> led_off\n");
        vTaskDelay(300 / portTICK_PERIOD_MS);
    }
}

