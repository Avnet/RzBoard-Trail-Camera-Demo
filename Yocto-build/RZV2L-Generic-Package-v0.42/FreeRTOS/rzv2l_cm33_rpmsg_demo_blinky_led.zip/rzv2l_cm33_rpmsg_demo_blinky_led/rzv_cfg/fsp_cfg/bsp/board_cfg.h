/* generated configuration header file - do not edit */
#ifndef BOARD_CFG_H_
#define BOARD_CFG_H_
#include "../../../rzv/board/rzv2l_smarc/board.h"
#endif /* BOARD_CFG_H_ */
