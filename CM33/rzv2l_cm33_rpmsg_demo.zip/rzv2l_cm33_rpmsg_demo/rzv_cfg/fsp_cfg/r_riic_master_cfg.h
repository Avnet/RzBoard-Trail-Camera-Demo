/* generated configuration header file - do not edit */
#ifndef R_RIIC_MASTER_CFG_H_
#define R_RIIC_MASTER_CFG_H_
#define RIIC_MASTER_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)
#define RIIC_MASTER_CFG_ADDR_MODE_10_BIT_ENABLE (0)
#endif /* R_RIIC_MASTER_CFG_H_ */
