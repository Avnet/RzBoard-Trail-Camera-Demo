/* generated configuration header file - do not edit */
#ifndef R_CSI2_CFG_H_
#define R_CSI2_CFG_H_
#ifdef __cplusplus
        extern "C" {
        #endif

#define CSI2_CFG_PARAM_CHECKING_ENABLE (BSP_CFG_PARAM_CHECKING_ENABLE)

#ifdef __cplusplus
        }
        #endif
#endif /* R_CSI2_CFG_H_ */
