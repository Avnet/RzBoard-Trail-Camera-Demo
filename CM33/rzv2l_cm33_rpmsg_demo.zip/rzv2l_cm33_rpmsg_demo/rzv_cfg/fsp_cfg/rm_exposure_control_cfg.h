/* generated configuration header file - do not edit */
#ifndef RM_EXPOSURE_CONTROL_CFG_H_
#define RM_EXPOSURE_CONTROL_CFG_H_
#ifdef __cplusplus
extern "C" {
#endif

#define RM_EXPOSURE_CONTROL_CFG_PARAM_CHECKING_ENABLE   FSP_NOT_DEFINED

#ifdef __cplusplus
}
#endif
#endif /* RM_EXPOSURE_CONTROL_CFG_H_ */
