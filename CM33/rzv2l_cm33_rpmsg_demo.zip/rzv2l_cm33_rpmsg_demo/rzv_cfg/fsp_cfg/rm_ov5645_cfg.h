/* generated configuration header file - do not edit */
#ifndef RM_OV5645_CFG_H_
#define RM_OV5645_CFG_H_
#ifdef __cplusplus
extern "C" {
#endif

#define RM_OV5645_CFG_PARAM_CHECKING_ENABLE   (BSP_CFG_PARAM_CHECKING_ENABLE)
#define RM_OV5645_CFG_CAPTURE_TYPE_YUV422 ((1))
#define RM_OV5645_CFG_CAPTURE_TYPE_RAW8 ((0))
#define RM_OV5645_CFG_CAPTURE_TYPE_RAW10 ((0))
#define RM_OV5645_CFG_CAPTURE_SIZE_1280_720_HD ((0))
#define RM_OV5645_CFG_CAPTURE_SIZE_1920_1080_FHD ((1))

#ifdef __cplusplus
}
#endif
#endif /* RM_OV5645_CFG_H_ */
